(Trainer name bot for Pokemon)
 _______            __                                                          
/       \          /  |                                                         
$$$$$$$  | ______  $$ |   __   ______   _____  ____    ______   _______         
$$ |__$$ |/      \ $$ |  /  | /      \ /     \/    \  /      \ /       \        
$$    $$//$$$$$$  |$$ |_/$$/ /$$$$$$  |$$$$$$ $$$$  |/$$$$$$  |$$$$$$$  |       
$$$$$$$/ $$ |  $$ |$$   $$<  $$    $$ |$$ | $$ | $$ |$$ |  $$ |$$ |  $$ |       
$$ |     $$ \__$$ |$$$$$$  \ $$$$$$$$/ $$ | $$ | $$ |$$ \__$$ |$$ |  $$ |       
$$ |     $$    $$/ $$ | $$  |$$       |$$ | $$ | $$ |$$    $$/ $$ |  $$ |       
$$/       $$$$$$/  $$/   $$/  $$$$$$$/ $$/  $$/  $$/  $$$$$$/  $$/   $$/        
                                                                                
                                                                                
                                                                                
 __    __                                          _______               __     
/  \  /  |                                        /       \             /  |    
$$  \ $$ |  ______   _____  ____    ______        $$$$$$$  |  ______   _$$ |_   
$$$  \$$ | /      \ /     \/    \  /      \       $$ |__$$ | /      \ / $$   |  
$$$$  $$ | $$$$$$  |$$$$$$ $$$$  |/$$$$$$  |      $$    $$< /$$$$$$  |$$$$$$/   
$$ $$ $$ | /    $$ |$$ | $$ | $$ |$$    $$ |      $$$$$$$  |$$ |  $$ |  $$ | __ 
$$ |$$$$ |/$$$$$$$ |$$ | $$ | $$ |$$$$$$$$/       $$ |__$$ |$$ \__$$ |  $$ |/  |
$$ | $$$ |$$    $$ |$$ | $$ | $$ |$$       |      $$    $$/ $$    $$/   $$  $$/ 
$$/   $$/  $$$$$$$/ $$/  $$/  $$/  $$$$$$$/       $$$$$$$/   $$$$$$/     $$$$/  
                                                                                
                                                                                
                                                                                


This is a program that creates a twitch chat bot for you while you use the Universal Pokemon randomizer originally created by Stewart Marshall and adapted by Ajarmar. I am in no way affiliated with Mr. Marshall. This app is designed to take a user command from Twitch chat and add the name specified to the randomized pool. If the user starts with an add command, and meet the criteria you specified, the custom file the game uses for trainer names is modified. In the end, the broadcaster has full power and can still edit names manually. This works relatively simply. 

On boot, you see a small window show up. Click file in the upper left-hand corner, then click load. You are presented with a load dialog menu. For this to work, you need to navigate to your folder containing the universal pokemon randomizer and select this file (https://i.imgur.com/ENWYNd7.png). After selecting once, you never have to select again; this program remembers where it was. 

After you load the right file, hit 'Connect' in the 'File' menu. I CANNOT STRESS THIS ENOUGH. YOU NEED AN ALT TO USE AS YOUR BOT. This program doesn't let you connect if the bot is the same name as your channel. 'OAuth token' is just a fancy way of saying a password. In order to lookup your OAuth, you need to log in to Twitch on your alt, and then click on the button I provide. Copy and paste this into the program, along with filling in the other fields. Click 'Connect.'

Now you are connected. Type !pCommands in chat for a list of commands. Any modification to the file will be reflected in new seeds. The Universal Pokemon Randomizer can stay open while this is up. 

Notes:
I am in no way responsible for any damages caused. It is up to you in being responsible with this. Also, there is a list of forbidden words/phrases. You can add to or remove from (not recommended) at any time. To disconnect this bot from your chat, just close the program. Also, all inputs into this form are remembered for you.


Commands - !pCommands:
The commands for this bot are !pAdd, !pAddDouble, !pRemove and !pRemoveDouble. These commands accept strings. For example, !pAdd "abc" would be valid. Each command could take up to 2 strings. 1 vs 2 strings are as follows: !pAdd "(Trainer name)", !pAdd "(Trainer class)" "(Trainer name)" Type !pAbout for more info.

About - !pAbout:
This app is designed to take a user command from Twitch chat and add the name specified to the randomized pool. If the user starts with an add command, and meet the criteria you specified, the custom file the randomizer uses for trainer names is modified. In the end, the broadcaster has full power and can still edit names manually. Type !pCommands to get all the available commands.
