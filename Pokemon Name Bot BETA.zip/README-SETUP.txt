
 _______            __                                                          
/       \          /  |                                                         
$$$$$$$  | ______  $$ |   __   ______   _____  ____    ______   _______         
$$ |__$$ |/      \ $$ |  /  | /      \ /     \/    \  /      \ /       \        
$$    $$//$$$$$$  |$$ |_/$$/ /$$$$$$  |$$$$$$ $$$$  |/$$$$$$  |$$$$$$$  |       
$$$$$$$/ $$ |  $$ |$$   $$<  $$    $$ |$$ | $$ | $$ |$$ |  $$ |$$ |  $$ |       
$$ |     $$ \__$$ |$$$$$$  \ $$$$$$$$/ $$ | $$ | $$ |$$ \__$$ |$$ |  $$ |       
$$ |     $$    $$/ $$ | $$  |$$       |$$ | $$ | $$ |$$    $$/ $$ |  $$ |       
$$/       $$$$$$/  $$/   $$/  $$$$$$$/ $$/  $$/  $$/  $$$$$$/  $$/   $$/        
                                                                                
                                                                                
                                                                                
 __    __                                          _______               __     
/  \  /  |                                        /       \             /  |    
$$  \ $$ |  ______   _____  ____    ______        $$$$$$$  |  ______   _$$ |_   
$$$  \$$ | /      \ /     \/    \  /      \       $$ |__$$ | /      \ / $$   |  
$$$$  $$ | $$$$$$  |$$$$$$ $$$$  |/$$$$$$  |      $$    $$< /$$$$$$  |$$$$$$/   
$$ $$ $$ | /    $$ |$$ | $$ | $$ |$$    $$ |      $$$$$$$  |$$ |  $$ |  $$ | __ 
$$ |$$$$ |/$$$$$$$ |$$ | $$ | $$ |$$$$$$$$/       $$ |__$$ |$$ \__$$ |  $$ |/  |
$$ | $$$ |$$    $$ |$$ | $$ | $$ |$$       |      $$    $$/ $$    $$/   $$  $$/ 
$$/   $$/  $$$$$$$/ $$/  $$/  $$/  $$$$$$$/       $$$$$$$/   $$$$$$/     $$$$/  
                                                                                
                                                                                
                                                                                

This is a program that creates a twitch chat bot for you while you use the Universal Pokemon randomizer created by Stewart Marshall. I am in no way affiliated with Mr. Marshall. This app is designed to take a user command from Twitch chat and add the name specified to the randomized pool. If the user starts with an add command, and are mod/vip/have paid enough bits, the custom file the game uses for text is modified. If a command does not go through, a mod can add instead for free. Only moderators can use the remove commands. In the end, the broadcaster has full power and can still edit names manually. This works relatively simply. 

On boot, you see a small window show up like this https://i.imgur.com/XsnvDJO.png. Click file in the upper left-hand corner, then click load (https://i.imgur.com/3Mn4Heh.png). You are presented with a load dialog menu. For this to work, you need to navigate to your folder containing the universal pokemon randomizer and select this file (https://i.imgur.com/ENWYNd7.png). After selecting once, you never hve to  select again; this program remembers where it was. 

After you load the right file, your screen willlook like this: https://i.imgur.com/Lol0ay8.png. From here, hit 'Connect' in the 'File' menu. Your screen will look like this: https://i.imgur.com/YgGJcyB.png. I CANNOT STRESS THIS ENOUGH. YOU NEED AN ALT TO USE AS YOUR BOT. This program doesn't let you connect if the bot is the sane name as your channel. 'OAuth token' is just a fancy way of saying a password. In order to lookup your OAuth, you need to log in to Twitch on your alt, and then click on the button I provide. Copy and paste this into the program, along with filling in the other fields. Click 'Connect.'

When you see this: https://i.imgur.com/AQl2iS5.png, you are connected. Type !pCommands in chat for a list of commands. Any modification to the file will be reflected in new seeds. The Universal Pokemon Randomizer can stay open while this is up. 

Notes:
I am in no way responsible for any damages caused. It is up to you in being responsiible with this. Also, there is a list of forbidden words/phrases. You can add to or remove from (not reconnended) at any time. To disconnect this bot from your chat, just close the program. Also, all inputs into this form are remembered for you.